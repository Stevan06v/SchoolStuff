package com.company;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
	// write your code here

        System.out.println("Main.main");
        System.out.println("args = " + args);
        System.out.println("args = " + Arrays.deepToString(args));

    }
}
