package com.company;

public class Drawboard {
    int anz;
    Figures[] figures;

    public Drawboard(int anz) {
        this.anz = anz;
        figures= new Figures[anz];
    }

    public boolean addFigure(Figures f){
        for (int i = 0; i < this.figures.length; i++) {
            if(this.figures[i] == null){
                figures[i]=f;
                return true;
            }
        }
        return false;
    }

    public double calculateSurface(){
        double sum = 0.0;
        for (int i = 0; i < this.figures.length; i++) {
            if(this.figures[i] != null){
                sum += this.figures[i].flaeche();
            }
        }
        return sum;
    }

    public void printAll() {
        for (int i = 0; i < this.figures.length; i++) {
            if (this.figures[i] != null) {
                System.out.println(this.figures[i].toString());
            }
        }
    }


}
