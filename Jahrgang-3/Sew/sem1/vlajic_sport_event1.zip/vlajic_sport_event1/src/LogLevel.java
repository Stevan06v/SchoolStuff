public enum LogLevel {
    ERROR,
    TRACE
}