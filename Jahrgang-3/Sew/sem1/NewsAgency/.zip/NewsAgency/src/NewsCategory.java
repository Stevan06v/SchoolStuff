public enum NewsCategory {
    ECONOMY, LIFESTYLE, POLITICS, SPORTS, TECH
}
