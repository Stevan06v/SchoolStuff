/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package producerconsumertest;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author robreder
 */
public class MessagePool {
    /***
     * Constructor MessagePool with size of store as parameter
     * @param size 
     */
    private String[] _data;
    private int producer_index = -1;
    private int consumer_index = -1;
    private Semaphore prevent_consumer_underflow;
    private Semaphore prevent_producer_overflow;

    public MessagePool(int size) {
        // TODO
        this._data = new String[size];
        this.prevent_producer_overflow = new Semaphore(size);
        this.prevent_consumer_underflow = new Semaphore(0);
    }

    /***
     * get() is used from the consumer
     * @return 
     */
    public String get() {
        String value = "";
        consumer_index++;
        consumer_index = consumer_index % this._data.length;
        prevent_consumer_underflow.acquireUninterruptibly();

        synchronized (this){
            value = this._data[consumer_index];
            System.out.println(value + " fetched");
        }
        prevent_producer_overflow.release();
        return value;
    }

    /**
     * put is used from the producer to put an object to the data pool
     * @param value
     **/
    public void put(String value)  {
        producer_index = producer_index % this._data.length;
        prevent_producer_overflow.acquireUninterruptibly();
        synchronized (this) {
            this._data[producer_index] = value;
            System.out.println(value + " stored");
        }
        prevent_consumer_underflow.release();
    }
}
