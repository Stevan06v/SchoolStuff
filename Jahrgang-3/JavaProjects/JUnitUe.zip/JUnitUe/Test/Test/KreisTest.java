package Test;
import static org.junit.jupiter.api.Assertions.*;

class KreisTest {

    @org.junit.jupiter.api.Test
     void flaeche() {
    }

    @org.junit.jupiter.api.Test
    void getRad() {
    }



}