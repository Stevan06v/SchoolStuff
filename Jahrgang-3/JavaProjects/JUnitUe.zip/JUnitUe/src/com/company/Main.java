package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here


        Person p = new Person("Max", "Muster", 67);
        System.out.println(p.toString());



    }
}
