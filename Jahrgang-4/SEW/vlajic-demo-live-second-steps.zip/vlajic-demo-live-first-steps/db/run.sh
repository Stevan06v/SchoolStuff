#!/bin/zsh
docker-compose up --build