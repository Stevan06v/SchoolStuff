package at.htlleonding.demo.model;

public enum Gender {
    MALE,
    FEMALE
}
