//
//  Photo.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import Foundation

struct Photo: Codable, Identifiable {
    
    private (set) var albumId: Int = 0;
    private (set) var id: Int = 0;
    private (set) var title: String = "";
    private (set) var url: String = "";
    private (set) var thumbnailUrl: String = "";

    
    
}
