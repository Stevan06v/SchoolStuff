//
//  PhotoService.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import Foundation


class PhotoService {
    let dataURL = "https://jsonplaceholder.typicode.com/photos";
    
    
    public func getPhoto(id: Int) async -> Photo {
        let photoUrl = URL(string: "\(dataURL)/\(id)")!;
        var photo: Photo = Photo();
        
        if let (data, _) = try? await URLSession.shared.data(from: photoUrl){
            if let parsedData = try? JSONDecoder().decode(Photo.self, from: data){
                photo = parsedData;
            }else{
                print("Error while parsing...")
            }
        }else{
            print("Error while fetching...")
        }
        return photo;
    }
    
    public func loadPhotos(id: Int) async -> [Photo]{
        var photos: [Photo] = [];
        
        for i in 1...id{
            photos.append(await getPhoto(id: i))
        }
        return photos;
    }
}
