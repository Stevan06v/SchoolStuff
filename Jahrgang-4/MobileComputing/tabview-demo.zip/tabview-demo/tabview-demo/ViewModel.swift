//
//  ViewModel.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import Foundation


class ViewModel: ObservableObject{
    @Published var model: Model;
    
    public func attachPhotos(photos: [Photo]){
        model.attachPhotos(photos: photos)
    }
    public func attachAlbums(albums: [Album]){
        model.attachAlbum(albums: albums)
    }
    
    
    init(model: Model){
        self.model = model;
    }
}
