//
//  AlbumService.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import Foundation

class AlbumService{
    let dataURL = "https://jsonplaceholder.typicode.com/albums";
    
    public func getAlbum(id: Int) async -> Album {
        let photoUrl = URL(string: "\(dataURL)/\(id)")!;
        var album: Album = Album();
        
        if let (data, _) = try? await URLSession.shared.data(from: photoUrl){
            if let parsedData = try? JSONDecoder().decode(Album.self, from: data){
                album = parsedData;
            }else{
                print("Error while parsing...")
            }
        }else{
            print("Error while fetching...")
        }
        return album;
    }
    
    public func loadAlbums(id: Int) async -> [Album]{
        var albums: [Album] = [];
        
        for i in 1...id{
            albums.append(await getAlbum(id: i))
        }
        return albums;
    }
}
