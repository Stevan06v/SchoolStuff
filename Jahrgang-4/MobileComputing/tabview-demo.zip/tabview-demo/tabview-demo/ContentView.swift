//
//  ContentView.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var viewModel: ViewModel;
    var body: some View {
        
        TabView {
            
            HomeView()
                .tabItem { Label("Home", systemImage: "house") }
                .badge(2)
                .task {
                    let photos:[Photo] = await AlbumService().loadAlbums(id: 100);
                    viewModel.attachAlbums(albums: <#T##[Album]#>)(photos: photos)
                    print(photos);
                }
            
            PhotoView(photos: viewModel.model.photos)
                .tabItem { Label("Photos", systemImage: "photo")}
                .badge(64)
                    .task {
                        let photos:[Photo] = await PhotoService().loadPhotos(id: 100);
                        viewModel.attachPhotos(photos: photos)
                        print(photos);
                    }
            
        }
    }
}

struct HomeView: View{
    var body: some View{
        Text("Home");
    }
}

struct PhotoView: View{
    
    var photos: [Photo];
    
    var body: some View{

        List(photos){
            photo in
            
            Text(photo.title)
            AsyncImage(url: URL(string: photo.thumbnailUrl))
        }
    }
}

