//
//  tabview_demoApp.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import SwiftUI

fileprivate var model: Model = Model();

@main
struct tabview_demoApp: App {
    let viewModel: ViewModel = ViewModel(model: model);
    var body: some Scene {
        WindowGroup {
            ContentView(viewModel: viewModel)
        }
    }
}
