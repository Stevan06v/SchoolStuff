//
//  Model.swift
//  tabview-demo
//
//  Created by Stevan Vlajic on 11.01.24.
//

import Foundation


struct Model{
    var photos: [Photo] = []; 
    var albums: [Album] = [];

    
    public mutating func attachPhotos(photos: [Photo]){
        self.photos = photos;
    }
    public mutating func attachAlbum(albums: [Album]){
        self.albums = albums;
    }
}
