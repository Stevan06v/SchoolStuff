

import Foundation

struct Album: Codable, Identifiable{
    private (set) var userId: Int = 0;
    private (set) var id: Int = 0;
    private (set) var title: String = "";

}
