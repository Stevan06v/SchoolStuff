//
//  Receipe.swift
//  receipe-list
//
//  Created by Stevan Vlajic on 18.01.24.
//

import Foundation

struct Recipe: Identifiable, Decodable, Hashable {
    private(set) var id: Int;
    private(set) var name: String;
    private(set) var image: String;
    private(set) var ingredients: [String];
    private(set) var instructions: [String];
}
