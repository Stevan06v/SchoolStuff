//
//  receipe_listApp.swift
//  receipe-list
//
//  Created by Stevan Vlajic on 18.01.24.
//

import SwiftUI

fileprivate var recipeModel: RecipeModel = RecipeModel(recipes: []);


@main
struct receipe_listApp: App {
    let viewModel: RecipeViewModel = RecipeViewModel(recipeModel: recipeModel);
    var body: some Scene {
        WindowGroup {
            ContentView(viewModel: viewModel);
        }
    }
}
