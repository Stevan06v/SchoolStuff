//
//  ContentView.swift
//  receipe-list
//
//  Created by Stevan Vlajic on 18.01.24.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var viewModel: RecipeViewModel;
    
    var body: some View {
        TabView{
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill");
                }
            
            ReceipeView(recipes: viewModel.getRecipes())
                .tabItem {
                    Label("Recipes", systemImage: "light.recessed.fill");
                }.task {
                    await viewModel.attachRecipeModel(receipeModel: ReceipeService().getReceipes());
                    print(viewModel.getRecipes());
                }.badge(viewModel.getRecipes().count)
        }
    }
}


struct HomeView: View{
    var body: some View {
        
        Image(systemName: "oven")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 200.0, height: 200.0)
    }
}

struct ReceipeView: View{
    var recipes: [Recipe];
    
    var body: some View {
        NavigationStack {
            List(recipes) { recipe in
                HStack{
                    AsyncImage(url: URL(string: recipe.image)) {
                        image in
                        image.image?.resizable()
                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 70, height: 70)
                            .cornerRadius(10)
                    }
                    
                    NavigationLink(recipe.name, value: recipe)
                }
                
            }
            .navigationDestination(for: Recipe.self) { recipe in
                RecipeDetails(name: recipe.name, image: recipe.image, ingredients: recipe.ingredients, instructions: recipe.instructions)
            }
        }.navigationTitle("Sex")
    }
}

struct RecipeDetails: View{
    var name: String;
    var image: String;
    var ingredients: [String];
    var instructions: [String];
    
    
    var body: some View {
        Text(name.uppercased())
            .font(.title2.bold())
            .frame(alignment: .center)
        
        AsyncImage(url: URL(string: image)){
            image in image
                .image?
                .resizable()
                .clipShape(RoundedRectangle(cornerRadius: 15))
                .aspectRatio(contentMode: .fit)
                .frame(width: 400, height: 300)
            
        }.padding()
        
        Text("Ingredients:")
            .font(.title3.bold())
            .multilineTextAlignment(.leading)
            .lineLimit(nil)
        
        Text(ingredients.joined(separator: ", "))
        
        
        Text("Instructions:")
            .font(.title3.bold())
        
        
        Text(instructions.joined(separator: ", "))
    }
}

struct ContentView_Preview: PreviewProvider {
    static var recipeModel: RecipeModel = RecipeModel(recipes: []);
    static let viewModel: RecipeViewModel = RecipeViewModel(recipeModel: recipeModel)
    static var previews: some View {
        ContentView(viewModel: viewModel);
    }
}
