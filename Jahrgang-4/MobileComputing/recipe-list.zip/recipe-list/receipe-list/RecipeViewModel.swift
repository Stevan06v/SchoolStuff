//
//  ReceipeViewModel.swift
//  receipe-list
//
//  Created by Stevan Vlajic on 18.01.24.
//

import Foundation


class RecipeViewModel: ObservableObject {
    @Published private (set) var recipeModel: RecipeModel;
    
    public func attachRecipeModel(receipeModel: RecipeModel){
        self.recipeModel = receipeModel;
    }
    
    public func getRecipes() -> [Recipe]{
        return recipeModel.recipes;
    }
    
    init(recipeModel: RecipeModel){
        self.recipeModel = recipeModel;
    }
}
