//
//  ReceipeService.swift
//  receipe-list
//
//  Created by Stevan Vlajic on 18.01.24.
//

import Foundation


class ReceipeService {
    
    let dataUrl = "https://edufs.edu.htl-leonding.ac.at/~c.aberger/download/recipes/recipes.json";
    
    public func getReceipes() async -> RecipeModel{
        let recipeUrl = URL(string: dataUrl)!;
        var recipeModel: RecipeModel = RecipeModel(recipes: []);
        
        if let(data, _) = try? await URLSession.shared.data(from: recipeUrl){
            if let parsedData = try? JSONDecoder().decode(RecipeModel.self, from: data){
                recipeModel = parsedData;
            }else{
                print("Error while parsing....");
            }
        }else{
            print("Error while fetching....");

        }   
        return recipeModel;
    }
}
