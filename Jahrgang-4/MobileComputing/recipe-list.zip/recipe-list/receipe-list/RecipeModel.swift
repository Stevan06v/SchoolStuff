//
//  ReceipeModel.swift
//  receipe-list
//
//  Created by Stevan Vlajic on 18.01.24.
//

import Foundation


struct RecipeModel: Decodable{
    private (set) var recipes: [Recipe];
}
