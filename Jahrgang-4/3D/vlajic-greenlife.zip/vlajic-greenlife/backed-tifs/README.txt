Leider ist ein Fehler beim "backen" aufgetreten, welchen ich leider nicht lösen konnte. 
siehe screenshots. (alles andere ist vorhanden -> fehlerfreie fbx)
