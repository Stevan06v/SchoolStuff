import java.util.LinkedList;
import java.util.List;

public class Main {

    public static void main(String[] args) {


        List<String> list = new LinkedList<>();

        list.add("ok");




        /*
        SimpleLogger.getInstance().logTrace("Starting program.");

        SportsEvent cityNightRun = new SportsEvent("10. Linzer Sparkasse City Night Run");
        cityNightRun.readFromFile("data/linz_night_run.csv");
        System.out.println(cityNightRun);

        SportsEvent linzTriathlon = new SportsEvent("12. Linz Triathlon");
        linzTriathlon.readFromFile("data/linz_tria_complete.csv");
        System.out.println(linzTriathlon);

        SimpleLogger.getInstance().logTrace("Exiting program.");

         */
    }
}
