public enum AllergenType {
    A, B, C, D, E, F, G, H, L, M, N, O, P, R
}
