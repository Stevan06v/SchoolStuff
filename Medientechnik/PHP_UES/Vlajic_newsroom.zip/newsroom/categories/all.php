<?php
include("./categories/austria.php");
include("./categories/science.php");
include("./categories/sports.php");
?>

